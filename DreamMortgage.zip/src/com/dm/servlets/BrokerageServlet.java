package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class BrokerageServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		

		String customerDetails = req.getParameter("customerSelect");
		String role = "brokerage";
		
		
		
		if(customerDetails != null){
			
			int mortgageNumber = Integer.parseInt(customerDetails.substring(customerDetails.indexOf("-")+1));					
			String payLoad =   "{\"jsonrpc\": \"2.0\",\"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage\",\"args\":[\"{\\\"MortgageNumber\\\":"+mortgageNumber+"}\"]},\"secureContext\": \"admin\"},\"id\": 0 }";
			RestServiceClientServlet client = new RestServiceClientServlet();
			String chainCodeResponse = client.invokeChainCode(payLoad);

			JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
			String customerDataString = chainCodeReponseJson.getJSONObject("result").get("message").toString();
			JSONObject customerData = new JSONObject(customerDataString);
									
					req.setAttribute("grantedLoanAmount", customerData.get("GrantedLoanAmount"));
					req.setAttribute("rateOfInterest", customerData.get("RateofInterest"));
					req.setAttribute("pValuation", customerData.get("PropertyValuation"));
					req.setAttribute("cScore", customerData.get("CreditScore"));
					req.setAttribute("fNetworth", customerData.get("FinancialWorth"));
					req.setAttribute("rClassification", customerData.get("RiskClassification"));					
					req.setAttribute("rAReturn", customerData.get("RiskAdjustedReturn"));
					req.setAttribute("eACashflow", customerData.get("ExpectedAnnualCashflow"));
					req.setAttribute("rLAmount", customerData.get("RemainingMortgageAmount"));
					req.setAttribute("oCost", customerData.get("Ownershipcost"));
					req.setAttribute("mPAdress", customerData.get("MortagePropertyAddress"));
					req.setAttribute("mrtgageStage", customerData.get("MortgageStage"));
					req.setAttribute("mortgageNumber", customerData.get("MortgageNumber"));
					req.setAttribute("mrtgageDuration", (Integer)customerData.get("MortgageDuration")/365);
					req.setAttribute("mrtgageDate", customerData.get("MortgageStartDate"));
					
					dispatcher = req.getRequestDispatcher("/brokerageEntity.jsp");
			
	}
		else{
		List<String> customersData = new ArrayList<String>();
		
		String payLoad =  "{ \"jsonrpc\": \"2.0\", \"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage_portfolio\"},\"secureContext\": \"admin\"},\"id\": 0}";
	
		RestServiceClientServlet client = new RestServiceClientServlet();
		String chainCodeResponse = client.invokeChainCode(payLoad);

		JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
		String allCustomersData = chainCodeReponseJson.getJSONObject("result").get("message").toString();
		JSONObject chainCodeReponseJsonResult = new JSONObject(allCustomersData);
		
		JSONArray allCustomersMortgageNumbers = (JSONArray) chainCodeReponseJsonResult.get("MortgageNumbers");
		JSONArray allCustomersCustomerNames = (JSONArray) chainCodeReponseJsonResult.get("CustomerNames");
		
		for(int iterator=1; iterator<allCustomersMortgageNumbers.length();iterator++){
		
		String customerName_mortgageNumber =  allCustomersCustomerNames.getString(iterator)+"-"+allCustomersMortgageNumbers.getInt(iterator);
		customersData.add(customerName_mortgageNumber);
		
		}
		req.setAttribute("customersData", customersData);
		dispatcher = req.getRequestDispatcher("/brokerageCustomerSelect.jsp");
		}
		dispatcher.forward(req, resp);
	}
	
}