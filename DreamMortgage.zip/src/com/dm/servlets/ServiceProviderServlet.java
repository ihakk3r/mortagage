package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class ServiceProviderServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		
		String customerDetails = req.getParameter("customerSelect");
		String role = "serviceprovider";
		
		
		
		if(customerDetails != null){
			
			int mortgageNumber = Integer.parseInt(customerDetails.substring(customerDetails.indexOf("-")+1));					
			String payLoad =   "{\"jsonrpc\": \"2.0\",\"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage\",\"args\":[\"{\\\"MortgageNumber\\\":"+mortgageNumber+"}\"]},\"secureContext\": \"admin\"},\"id\": 0 }";
			RestServiceClientServlet client = new RestServiceClientServlet();
			String chainCodeResponse = client.invokeChainCode(payLoad);

			JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
			String customerDataString = chainCodeReponseJson.getJSONObject("result").get("message").toString();
			JSONObject customerData = new JSONObject(customerDataString);
									
					req.setAttribute("customerName", customerData.get("CustomerName"));
					req.setAttribute("customerSSN", customerData.get("CustomerSSN"));
					req.setAttribute("pValuation", customerData.get("PropertyValuation"));
					req.setAttribute("cScore", customerData.get("CreditScore"));
					req.setAttribute("fNetworth", customerData.get("FinancialWorth"));
					req.setAttribute("mortgageNumber", customerData.get("MortgageNumber"));
						
					dispatcher = req.getRequestDispatcher("/serviceProviderCustomer.jsp");
			
	}
		else {
			String updateCustomer = req.getParameter("updateCustomer");

			if (updateCustomer != null) {
				RestServiceClientServlet client = new RestServiceClientServlet();
				
				int pValuation = Integer.parseInt(req.getParameter("pValuation"));
				int creditScore =Integer.parseInt(req.getParameter("creditScore"));
				int fNetworth = Integer.parseInt(req.getParameter("fNetworth"));			
				int mrtgageNumber = Integer.parseInt(req.getParameter("mortgageNumber"));
				
				JSONObject customerData = client.getCustomerProperty(mrtgageNumber);
				boolean anyChange = false;
				String payLoadParameters = "";
				
						
					if((Integer)customerData.get("PropertyValuation")!=pValuation){
						payLoadParameters+=",\\\"PropertyValuation\\\" :"+pValuation;
						anyChange = true;
					}
					if((Integer)customerData.get("CreditScore")!=creditScore){
						payLoadParameters+=",\\\"CreditScore\\\" :"+creditScore;
						anyChange = true;
					}
					if((Integer)customerData.get("FinancialWorth")!=fNetworth){
						payLoadParameters+=",\\\"FinancialWorth\\\" :"+fNetworth;
						anyChange = true;
					}
					
				
				
				if(anyChange){
				
			    String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"+mrtgageNumber+",\\\"ModifiedBy\\\":\\\""+role+"\\\""+payLoadParameters+"}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";							
				String chainCodeResponse = client.invokeChainCode(payLoad);
				
				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				String status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

				if(status.equals("OK"))	
					req.setAttribute("successMsg", "Data updated succesfully for Mortgage Number: "+mrtgageNumber);
				else
					req.setAttribute("failureMsg", "Error! Please come back and try again later");
					
						
				}
				else{
					req.setAttribute("failureMsg", "No changes made to the form, To update please edit the details and submit the form.");
					
				}
				
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				customerData = client.getCustomerProperty(mrtgageNumber);
				
				req.setAttribute("customerName", customerData.get("CustomerName"));
				req.setAttribute("customerSSN", customerData.get("CustomerSSN"));
				req.setAttribute("pValuation", customerData.get("PropertyValuation"));
				req.setAttribute("cScore", customerData.get("CreditScore"));
				req.setAttribute("fNetworth", customerData.get("FinancialWorth"));
				req.setAttribute("rClassification", customerData.get("RiskClassification"));			
				req.setAttribute("mortgageNumber", customerData.get("MortgageNumber"));
				
			
				
				dispatcher = req.getRequestDispatcher("/serviceProviderCustomer.jsp");
						
			

			}
		
		else{
		List<String> customersData = new ArrayList<String>();
		
		String payLoad =  "{ \"jsonrpc\": \"2.0\", \"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage_portfolio\"},\"secureContext\": \"admin\"},\"id\": 0}";
	
		RestServiceClientServlet client = new RestServiceClientServlet();
		String chainCodeResponse = client.invokeChainCode(payLoad);

		JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
		String allCustomersData = chainCodeReponseJson.getJSONObject("result").get("message").toString();
		JSONObject chainCodeReponseJsonResult = new JSONObject(allCustomersData);
		
		JSONArray allCustomersMortgageNumbers = (JSONArray) chainCodeReponseJsonResult.get("MortgageNumbers");
		JSONArray allCustomersCustomerNames = (JSONArray) chainCodeReponseJsonResult.get("CustomerNames");
		
		for(int iterator=1; iterator<allCustomersMortgageNumbers.length();iterator++){
		
		String customerName_mortgageNumber =  allCustomersCustomerNames.getString(iterator)+"-"+allCustomersMortgageNumbers.getInt(iterator);
		customersData.add(customerName_mortgageNumber);
		
		}
		req.setAttribute("customersData", customersData);
		dispatcher = req.getRequestDispatcher("/serviceProviderSelect.jsp");
		}
		
	}
		
		dispatcher.forward(req, resp);
	
}
	
}
