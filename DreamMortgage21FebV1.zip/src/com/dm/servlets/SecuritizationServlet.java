package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;

public class SecuritizationServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = null;		
		String customerSelect = request.getParameter("customerSelect");
		String role = "securitization";
		RestServiceClientServlet client = new RestServiceClientServlet();
		
		
			if(customerSelect != null){
			
			int mortgageNumber = Integer.parseInt(customerSelect.substring(customerSelect.indexOf("-")+1));					
			CustomerDetails customerDetails =  client.getCustomerDetails(mortgageNumber);

			request.setAttribute("customerDetails", customerDetails);
					//Need to write conditional readonly here
								
					dispatcher = request.getRequestDispatcher("/securtizationEntityCustomer.jsp");
									
		
	}
		
		
		else {
			String updateCustomer = request.getParameter("updateCustomer");

			if (updateCustomer != null) {
				
				String mStage = request.getParameter("mStage");						
				int mortagageNumber = Integer.parseInt(request.getParameter("mortgageNumber"));
				
				CustomerDetails customerData = client.getCustomerDetails(mortagageNumber);
				boolean anyChange = false;
				String payLoadParameters = "";
				
			
						payLoadParameters+=",\\\"MortgageStage\\\" : \\\""+mStage+"\\\"";
						anyChange = true;
					
			
				if(anyChange){
				
			    String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"+mortagageNumber+",\\\"ModifiedBy\\\":\\\""+role+"\\\""+payLoadParameters+"}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";							
				String chainCodeResponse = client.invokeChainCode(payLoad);
				
				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				String status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

				if(status.equals("OK"))	
					request.setAttribute("successMsg", "Data updated succesfully for Mortgage Number: "+mortagageNumber);
				else
					request.setAttribute("failureMsg", "Error! Please come back and try again later");
					
						
				}
				else{
					request.setAttribute("failureMsg", "No changes made to the form, To update please edit the details and submit the form.");
					
				}
								
				customerData = client.getCustomerDetails(mortagageNumber);
				
				request.setAttribute("customerDetails", customerData);
										
				//if(customerData.getString("MortgageStage").contains("Disbursed"))
					//request.setAttribute("disbursed", "readonly");
				//else
					//request.setAttribute("notDisbursed", "readonly");
				
	
			dispatcher = request.getRequestDispatcher("/otherBCustomerDetails.jsp");
					
			

			}
			else{
		
		List<String> customersData = new ArrayList<String>();
		
		String payLoad =  "{ \"jsonrpc\": \"2.0\", \"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage_portfolio\"},\"secureContext\": \"admin\"},\"id\": 0}";
	
		String chainCodeResponse = client.invokeChainCode(payLoad);

		JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
		String allCustomersData = chainCodeReponseJson.getJSONObject("result").get("message").toString();
		JSONObject chainCodeReponseJsonResult = new JSONObject(allCustomersData);
		
		JSONArray allCustomersMortgageNumbers = (JSONArray) chainCodeReponseJsonResult.get("MortgageNumbers");
		JSONArray allCustomersCustomerNames = (JSONArray) chainCodeReponseJsonResult.get("CustomerNames");
		
		for(int iterator=1; iterator<allCustomersMortgageNumbers.length();iterator++){
		
		String customerName_mortgageNumber =  allCustomersCustomerNames.getString(iterator)+"-"+allCustomersMortgageNumbers.getInt(iterator);
		customersData.add(customerName_mortgageNumber);
		
		}
		request.setAttribute("customersData", customersData);
		dispatcher = request.getRequestDispatcher("/securitizationEntitySelect.jsp");
		
		}
		
	}
		dispatcher.forward(request, response);
}
	
}
