package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;


public class PartnerBankServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public PartnerBankServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
					
		RequestDispatcher dispatcher = null;		
		String customerDetails = request.getParameter("customerSelect");
		String role = "partnerbank";
				
		if(customerDetails != null){
			
			int mortgageNumber = Integer.parseInt(customerDetails.substring(customerDetails.indexOf("-")+1));					
			String payLoad =   "{\"jsonrpc\": \"2.0\",\"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage\",\"args\":[\"{\\\"MortgageNumber\\\":"+mortgageNumber+"}\"]},\"secureContext\": \"admin\"},\"id\": 0 }";
			RestServiceClientServlet client = new RestServiceClientServlet();
			String chainCodeResponse = client.invokeChainCode(payLoad);

			JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
			String customerDataString = chainCodeReponseJson.getJSONObject("result").get("message").toString();
			JSONObject customerData = new JSONObject(customerDataString);
									
					request.setAttribute("customerName", customerData.get("CustomerName"));
					request.setAttribute("customerAddress", customerData.get("CustomerAddress"));
					request.setAttribute("customerSSN", customerData.get("CustomerSSN"));
					request.setAttribute("customerDOB", customerData.get("CustomerDOB"));
					request.setAttribute("grantedLoanAmount", customerData.get("GrantedLoanAmount"));
					request.setAttribute("rateOfInterest", customerData.get("RateofInterest"));
					request.setAttribute("pValuation", customerData.get("PropertyValuation"));
					request.setAttribute("loanAmount", customerData.get("ReqLoanAmount"));
					request.setAttribute("cScore", customerData.get("CreditScore"));
					request.setAttribute("fNetworth", customerData.get("FinancialWorth"));
					request.setAttribute("rClassification", customerData.get("RiskClassification"));					
					request.setAttribute("rAReturn", customerData.get("RiskAdjustedReturn"));
					request.setAttribute("eACashflow", customerData.get("ExpectedAnnualCashflow"));
					request.setAttribute("rLAmount", customerData.get("RemainingMortgageAmount"));
					request.setAttribute("oCost", customerData.get("Ownershipcost"));
					request.setAttribute("lPaymentAmount", customerData.get("LastPaymentAmount"));
					request.setAttribute("mPAdress", customerData.get(""));
					request.setAttribute("mrtgageStage", customerData.get("MortgageStage"));
					request.setAttribute("mrtgageType", customerData.get("MortgageType"));
					request.setAttribute("mrtgageDate", customerData.get("MortgageStartDate"));
					request.setAttribute("mrtgageDuration", (Integer)customerData.get("MortgageDuration")/365);
					request.setAttribute("mortgageNumber", customerData.get("MortgageNumber"));
					
					//Need to write conditional readonly here
								
					dispatcher = request.getRequestDispatcher("/otherBCustomerDetails.jsp");
									
		
	}
		
		
		else {
			String updateCustomer = request.getParameter("updateCustomer");

			if (updateCustomer != null) {
				RestServiceClientServlet client = new RestServiceClientServlet();
				
				String mStage = request.getParameter("mStage");						
				int mortgageNumber = Integer.parseInt(request.getParameter("mortgageNumber"));
				
				CustomerDetails customerData = client.getCustomerDetails(mortgageNumber);
				boolean anyChange = false;
				String payLoadParameters = "";
				
			
						payLoadParameters+=",\\\"MortgageStage\\\" : \\\""+mStage+"\\\"";
						anyChange = true;
					
			
				if(anyChange){
				
			    String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"+mortgageNumber+",\\\"ModifiedBy\\\":\\\""+role+"\\\""+payLoadParameters+"}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";							
				String chainCodeResponse = client.invokeChainCode(payLoad);
				
				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				String status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

				if(status.equals("OK"))	
					request.setAttribute("successMsg", "Data updated succesfully for Mortgage Number: "+mortgageNumber);
				else
					request.setAttribute("failureMsg", "Error! Please come back and try again later");
					
						
				}
				else{
					request.setAttribute("failureMsg", "No changes made to the form, To update please edit the details and submit the form.");
					
				}
				
				
				customerData = client.getCustomerDetails(mortgageNumber);
				
				request.setAttribute("customerDetails", customerData);
				
				
				
				//if(customerData.getString("MortgageStage").contains("Disbursed"))
					//request.setAttribute("disbursed", "readonly");
				//else
					//request.setAttribute("notDisbursed", "readonly");
				
	
				dispatcher = request.getRequestDispatcher("/otherBCustomerDetails.jsp");
					
			

			} else {
				
				List<String> customersData = new ArrayList<String>();
				
				String payLoad =  "{ \"jsonrpc\": \"2.0\", \"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage_portfolio\"},\"secureContext\": \"admin\"},\"id\": 0}";
			
				RestServiceClientServlet client = new RestServiceClientServlet();
				String chainCodeResponse = client.invokeChainCode(payLoad);
	
				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				String allCustomersData = chainCodeReponseJson.getJSONObject("result").get("message").toString();
				JSONObject chainCodeReponseJsonResult = new JSONObject(allCustomersData);
				
				String tempMortgageObject = chainCodeReponseJsonResult.get("MortgageNumbers").toString();				
				if (!tempMortgageObject.equals("null")) {
					
				
				JSONArray allCustomersMortgageNumbers = (JSONArray) chainCodeReponseJsonResult.get("MortgageNumbers");
				JSONArray allCustomersCustomerNames = (JSONArray) chainCodeReponseJsonResult.get("CustomerNames");
				
				for(int iterator=1; iterator<allCustomersMortgageNumbers.length();iterator++){
				
				String customerName_mortgageNumber =  allCustomersCustomerNames.getString(iterator)+"-"+allCustomersMortgageNumbers.getInt(iterator);
				customersData.add(customerName_mortgageNumber);
				}
				
				if(customersData.size()!=0)
					request.setAttribute("customersData", customersData);
				else
					request.setAttribute("errorMsg", "Sorry! No data available for your query");
				
				dispatcher = request.getRequestDispatcher("/otherBselectCustomer.jsp");
						
				}
				else
					request.setAttribute("errorMsg", "Sorry! No data available for your query");
			}
		}
		dispatcher.forward(request, response);	
		
	}
	

}
