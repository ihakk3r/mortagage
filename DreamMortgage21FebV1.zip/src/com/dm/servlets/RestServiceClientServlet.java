package com.dm.servlets;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import org.json.JSONObject;

import com.dm.beans.CustomerDetails;
import com.google.gson.Gson;

public class RestServiceClientServlet {
	
	private String chainCodeId;
	private String vip;
	
	public void initClient() {
		InputStream inputStream = null;
		try {
			Properties prop = new Properties();
			String propFileName = "blockchain.properties";
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
 
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
			 chainCodeId = prop.getProperty("ChaincodeID");
			 vip = prop.getProperty("Vip");
			
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public String invokeChainCode(String payLoad) throws IOException{
		
		initClient();
		
		String chainCodeResponseString = null;
		HttpURLConnection connection = null;
		BufferedReader in = null;
		OutputStreamWriter out = null;
		
		
		JSONObject jsonPayLoad = new JSONObject(payLoad);
		JSONObject paramsObject = jsonPayLoad.getJSONObject("params");
		JSONObject chaincodeIDObject = paramsObject.getJSONObject("chaincodeID");
		chaincodeIDObject.put("name", chainCodeId);
		paramsObject.put("chaincodeID", chaincodeIDObject);
		jsonPayLoad.put("params", paramsObject);
		
		try {			
		URL url = new URL("https://"+vip+"/chaincode");
		System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		 connection = (HttpURLConnection)url.openConnection();
		connection.setDoOutput(true);
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setConnectTimeout(10000);
		connection.setReadTimeout(5000);
		out = new OutputStreamWriter(connection.getOutputStream());
		out.write(jsonPayLoad.toString());
		out.close();
		
		in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		chainCodeResponseString=in.readLine();		
		
		
		}
		catch (Exception e) {
			System.out.println("Exception : "+e.toString());
		}
		
			finally {
			    if (in != null) {
			        try {
			        	in.close();
			        	out.close();
			        } catch (IOException e) {
			        }
			    }
			    if (connection != null) {
			    	connection.disconnect();
			   }
			}
		
		
		return chainCodeResponseString;
		
	}
	
	
public CustomerDetails getCustomerDetails(int mortgageNumber){
		
		String payLoad = "{\"jsonrpc\": \"2.0\",\"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage\",\"args\":[\"{\\\"MortgageNumber\\\":"
				+ mortgageNumber + "}\"]},\"secureContext\": \"admin\"},\"id\": 0 }";
		RestServiceClientServlet client = new RestServiceClientServlet();
		String chainCodeResponse = null;
		try {
			chainCodeResponse = client.invokeChainCode(payLoad);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
		String customerDataString = chainCodeReponseJson.getJSONObject("result").get("message").toString();
		CustomerDetails customerDetails = new Gson().fromJson(customerDataString, CustomerDetails.class);
		return customerDetails;
		
	}

/* Remove below method and references in production */

public CustomerDetails getDummyCustomerObject(){
	
	CustomerDetails customer = new CustomerDetails("Jane", "Bloomington", 313146466, "02/05/1970", 50000, 3.05, 90000, 70000, 240, 1000000, "A", 2, 10000, 60000, 0, 1000, "Texas", "Disbursed:Ready to Purchase", "", "FIXED", "02/05/2017", 3650, false, "securitization", 100002);
	
	return customer;	
}

}
