package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;

public class BrokerageServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		

		String customerSelect = req.getParameter("customerSelect");
		String role = "Brokerage";
		RestServiceClientServlet client = new RestServiceClientServlet();
		
		
		if(customerSelect != null){
			
			int mortgageNumber = Integer.parseInt(customerSelect.substring(customerSelect.indexOf("-")+1));					
			CustomerDetails customerDetails =  client.getCustomerDetails(mortgageNumber);

			req.setAttribute("customerDetails", customerDetails);
			dispatcher = req.getRequestDispatcher("/brokerageEntity.jsp");
			
		}
		else{
		List<String> customersData = new ArrayList<String>();
		
		String payLoad =  "{ \"jsonrpc\": \"2.0\", \"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage_portfolio\"},\"secureContext\": \"admin\"},\"id\": 0}";

		String chainCodeResponse = client.invokeChainCode(payLoad);

		JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
		String allCustomersData = chainCodeReponseJson.getJSONObject("result").get("message").toString();
		JSONObject chainCodeReponseJsonResult = new JSONObject(allCustomersData);
		String tempMortgageObject = chainCodeReponseJsonResult.get("MortgageNumbers").toString();				
			if (!tempMortgageObject.equals("null")) {

				JSONArray allCustomersMortgageNumbers = (JSONArray) chainCodeReponseJsonResult.get("MortgageNumbers");
				JSONArray allCustomersCustomerNames = (JSONArray) chainCodeReponseJsonResult.get("CustomerNames");

				for (int iterator = 0; iterator < allCustomersMortgageNumbers.length(); iterator++) {

					String customerName_mortgageNumber = allCustomersCustomerNames.getString(iterator) + "-"
							+ allCustomersMortgageNumbers.getInt(iterator);
					customersData.add(customerName_mortgageNumber);

				}
				if(customersData.size()!=0)
					req.setAttribute("customersData", customersData);
				else
					req.setAttribute("errorMsg", "Sorry! No data available for your query");
				dispatcher = req.getRequestDispatcher("/brokerageCustomerSelect.jsp");
			}
			else
				req.setAttribute("errorMsg", "Sorry! No data available for your query");
		}
		dispatcher.forward(req, resp);
	}
	
}