package com.dm.beans;

import java.sql.Timestamp;

public class AuditorBean {
	private String MortgageNumber;
	private String Participant;
	private String Action;
	private String Data;
	private String timeStamp;
	
	public String getMortgageNumber() {
		return MortgageNumber;
	}
	public void setMortgageNumber(String mortgageNumber) {
		MortgageNumber = mortgageNumber;
	}
	public String getParticipant() {
		return Participant;
	}
	public void setParticipant(String participant) {
		Participant = participant;
	}
	public String getAction() {
		return Action;
	}
	public void setAction(String action) {
		Action = action;
	}
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
}
