package com.dm.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import org.json.JSONObject;

/**
 * Servlet implementation class AuditorsServlet
 */

public class AuditorsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuditorsServlet() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = null;
		RestServiceClientServlet client = new RestServiceClientServlet();
		String payLoad1 = null;
		String chainCodeResponse = client.invokeChainCodeAuditor(payLoad1);
		JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
		
		String height = chainCodeReponseJson.get("height").toString();
		if(height != null)
			for(int i = 0; i < Integer.parseInt(height); i++) {
				String customer = client.invokeChainCodeAuditorCustomer(payLoad1, Integer.toString(i));
				JSONObject customerJson = new JSONObject(chainCodeResponse);
				
				if(customerJson.getBoolean("type")) {
					if("2".equals(customerJson.get("type")) && customerJson.getBoolean("payload")) {
						String payLoad = customerJson.getString("payload").toString();
						String res = new String(DatatypeConverter.parseBase64Binary(payLoad));
						//JSONObject res = new JSONObject(new String(DatatypeConverter.parseBase64Binary(payLoad)));
						if(res.contains("reate_mortgage_application")) {
							
						}
						else if(res.contains("modify_mortgage")) {
							
						}
					}
				}
				
				
			}
		}
	}
