package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;

public class BankServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BankServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher dispatcher = null;

		String role = "Lending Bank";
		String action = request.getParameter("action");
		RestServiceClientServlet client = new RestServiceClientServlet();

		if (action.equals("getCustomer")) {
		//This module retrieves a single mortgage application from blockchain json
			String customerSelect = request.getParameter("customerSelect");

			int mortgageNumber = Integer.parseInt(customerSelect.substring(customerSelect.indexOf("-") + 1));
			CustomerDetails customerDetails = client.getCustomerDetails(mortgageNumber);

			String mortgageStage = customerDetails.getMortgageStage();
			String mortgagePropertyOwnership = customerDetails.getMortgagePropertyOwnership();
			
			// Write and readonly conditions go here
			
			if (!customerDetails.getMortgageStage().equals("Disbursed:")) {
				request.setAttribute("disbursed", "readonly");
				request.setAttribute("disabled", "disabled");
			} else if(mortgageStage.equals("Disbursed:")||mortgagePropertyOwnership.equals("Pending Bank"))
				request.setAttribute("notDisbursed", "readonly");
			
			request.setAttribute("customerDetails", customerDetails);
			dispatcher = request.getRequestDispatcher("/bankCustomerDetails.jsp");

		}

		else if (action.equals("put")) {
			//This module modifies a mortagage application based on mortgage number and other inputs
			String actionType = request.getParameter("type");
			String mortgageStage = "";

			/* Building the mortgageStage based on the put action 'type' parameter. */
			if (actionType.equals("additional"))
				mortgageStage = "Pending-Customer:";
			else if (actionType.equals("approve"))
				mortgageStage = "Approved:";
			else if (actionType.equals("deny"))
				mortgageStage = "Denied:";
			else
				mortgageStage = "Pending-Bank:";

			// mortgageStage = "Disbursed:Ready to Purchase"; --Used as
			// hardcoded data when inserting customer data manually

			String mPAdress = request.getParameter("mPAdress");
			int gloanAmount = Integer.parseInt(request.getParameter("gloanAmount"));
			double rateOfInterest = Double.parseDouble(request.getParameter("rateOfInterest"));
			String mrtgageStartDate = request.getParameter("mrtgageStartDate");
			int mrtgageDuration = Integer.parseInt(request.getParameter("mrtgageDuration"));
			int pValuation = Integer.parseInt(request.getParameter("pValuation"));
			int creditScore = Integer.parseInt(request.getParameter("creditScore"));
			int fNetworth = Integer.parseInt(request.getParameter("fNetworth"));
			int mortgageNumber = Integer.parseInt(request.getParameter("mortgageNumber"));
			int lpAmount = Integer.parseInt(request.getParameter("lpAmount"));

			CustomerDetails customerData = client.getCustomerDetails(mortgageNumber);
			boolean anyChange = false;
			String payLoadParameters = "";

			if ((Integer) customerData.getLastPaymentAmount() != lpAmount) {
				payLoadParameters += ",\\\"LastPaymentAmount\\\" :" + lpAmount;
				anyChange = true;
			}

			if (!customerData.getMortgageStage().equals(mortgageStage)) {

				payLoadParameters += ",\\\"MortgageStage\\\" :\\\"" + mortgageStage + "\\\"";
				anyChange = true;

			}

			if (!mPAdress.equals(customerData.getMortgagePropertyAddress())) {
				payLoadParameters += ",\\\"MortgagePropertyAddress\\\" : \\\"" + mPAdress + "\\\"";
				anyChange = true;
			}

			if ((Integer) customerData.getGrantedLoanAmount() != gloanAmount) {
				payLoadParameters += ",\\\"GrantedLoanAmount\\\" :" + gloanAmount;
				anyChange = true;
			}
			if ((Double) customerData.getRateofInterest() != rateOfInterest) {
				payLoadParameters += ",\\\"RateofInterest\\\" :" + rateOfInterest;
				anyChange = true;
			}

			if ((Integer) customerData.getMortgageDuration() != mrtgageDuration) {
				payLoadParameters += ",\\\"MortgageDuration\\\" :" + mrtgageDuration;
				anyChange = true;
			}
			if ((Integer) customerData.getPropertyValuation() != pValuation) {
				payLoadParameters += ",\\\"PropertyValuation\\\" :" + pValuation;
				anyChange = true;
			}
			if ((Integer) customerData.getCreditScore() != creditScore) {
				payLoadParameters += ",\\\"CreditScore\\\" :" + creditScore;
				anyChange = true;
			}
			if ((Integer) customerData.getFinancialWorth() != fNetworth) {
				payLoadParameters += ",\\\"FinancialWorth\\\" :" + fNetworth;
				anyChange = true;
			}
			if (!mrtgageStartDate.equals(customerData.getMortgageStartDate())) {
				payLoadParameters += ",\\\"MortgageStartDate\\\" : \\\"" + mrtgageStartDate + "\\\"";
				anyChange = true;
			}

			if (anyChange) {

				String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"
						+ mortgageNumber + ",\\\"ModifiedBy\\\":\\\"" + role + "\\\"" + payLoadParameters
						+ "}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";
				String chainCodeResponse = client.invokeChainCode(payLoad);

				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				String status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

				if (status.equals("OK"))
					request.setAttribute("successMsg",
							"Data updated succesfully for Mortgage Number: " + mortgageNumber);
				else
					request.setAttribute("failureMsg", "Error! Please come back and try again later");

			} else {
				request.setAttribute("failureMsg",
						"No changes made to the form, To update please edit the details and submit the form.");

			}

			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			customerData = client.getCustomerDetails(mortgageNumber);

			request.setAttribute("customerDetails", customerData);

			if (!customerData.getMortgageStage().equals("Disbursed:")) {
				request.setAttribute("disbursed", "readonly");
				request.setAttribute("disabled", "disabled");
			} else if(customerData.getMortgageStage().equals("Disbursed:")||customerData.getMortgagePropertyOwnership().equals("Pending Bank"))
				request.setAttribute("notDisbursed", "readonly");
			
			dispatcher = request.getRequestDispatcher("/bankCustomerDetails.jsp");

		} else if (action.equals("getAll")) {
			
			// This module retrieves all mortgage applications with "Pending-Bank:" , "Pending-Customer" , and "Approved:" mortageStages.
			List<String> customersData = new ArrayList<String>();

			String payLoad = "{ \"jsonrpc\": \"2.0\", \"method\": \"query\",\"params\": {\"type\": 1,\"chaincodeID\": {\"name\": \"\"},\"ctorMsg\": {\"function\": \"retrieve_mortgage_portfolio\"},\"secureContext\": \"admin\"},\"id\": 0}";

			String chainCodeResponse = client.invokeChainCode(payLoad);

			JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
			String allCustomersData = chainCodeReponseJson.getJSONObject("result").get("message").toString();
			JSONObject chainCodeReponseJsonResult = new JSONObject(allCustomersData);

			String tempMortgageObject = chainCodeReponseJsonResult.get("MortgageNumbers").toString();
			if (!tempMortgageObject.equals("null")) {

				JSONArray allCustomersMortgageNumbers = (JSONArray) chainCodeReponseJsonResult.get("MortgageNumbers");
				JSONArray allCustomersCustomerNames = (JSONArray) chainCodeReponseJsonResult.get("CustomerNames");
				JSONArray allMortgageStages = (JSONArray) chainCodeReponseJsonResult.get("MortgageStages");

				for (int iterator = 0; iterator < allCustomersMortgageNumbers.length(); iterator++) {
					String customerName = allCustomersCustomerNames.getString(iterator);
					int mortgageNumber = allCustomersMortgageNumbers.getInt(iterator);
					String mortgageStage = allMortgageStages.getString(iterator);

					if ((customerName != null) && (mortgageStage.equals("Pending-Bank:")
							|| mortgageStage.equals("Pending-Customer:") || mortgageStage.equals("Approved:"))) {

						String customerName_mortgageNumber = customerName + "-" + mortgageNumber;
						customersData.add(customerName_mortgageNumber);
					}
				}
				if (customersData.size() != 0)
					request.setAttribute("customersData", customersData);
				else
					request.setAttribute("errorMsg", "Sorry! No data available for your query");
				dispatcher = request.getRequestDispatcher("/bankSelectCustomer.jsp");
			} else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
		}

		else if (action.equals("getGse")) {
			// This module retrieves all mortgage applications with "Disbursed:Ready to Purchase" mortageStage.
			
			List<CustomerDetails> gseCustomerList = new ArrayList<CustomerDetails>();

			List<Integer> gseMortgageNumbers = client.getMortgagesByStage("Disbursed:Ready to Purchase");
			for (int eachGseMortgageNumber : gseMortgageNumbers) {

				CustomerDetails customerDetails = client.getCustomerDetails(eachGseMortgageNumber);
				gseCustomerList.add(customerDetails);

			}
			/* Dummy Data for inserting a customer - This can be Used for testing all other functions */
			/*
			 * CustomerDetails dummyCustomerData=
			 * client.getDummyCustomerObject();
			 * gseCustomerList.add(dummyCustomerData);
			 * gseCustomerList.add(dummyCustomerData);
			 */

			if (gseCustomerList.size() != 0)
				request.setAttribute("gseCustomerList", gseCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/bankGseApprovals.jsp");

		} else if (action.equals("sellGSE")) {
			//This module writes ownership cost for a individual mortgage
			String status = "";
			String[] selectCustomerMortgageNumbers = request.getParameterValues("customer");
			int discountPercentage = Integer.parseInt(request.getParameter("discountPercentage"));

			for (String eachGseMortgage : selectCustomerMortgageNumbers) {
				int eachGseMortgageNumber = Integer.parseInt(eachGseMortgage);
				CustomerDetails customerDetails = client.getCustomerDetails(Integer.parseInt(eachGseMortgage));
				int ownershipCost = (customerDetails.getRemainingMortgageAmount() * (100 - discountPercentage)) / 100;
				String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"
						+ eachGseMortgageNumber + ",\\\"ModifiedBy\\\":\\\"" + role + "\\\",\\\"Ownershipcost\\\":"
						+ ownershipCost + "}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";
				String chainCodeResponse = client.invokeChainCode(payLoad);

				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

			}
			if (status.equals("OK"))
				request.setAttribute("successMsg", "Data updated successfully.");
			else
				request.setAttribute("failureMsg", "Error! Please come back and try again later.");
			dispatcher = request.getRequestDispatcher("/bankGseApprovals.jsp");
			
			
		} else if (action.equals("getAuction")) {
			// This module retrieves all mortgage applications with "Disbursed:" mortageStage.
			
			List<CustomerDetails> auctionCustomerList = new ArrayList<CustomerDetails>();
			List<Integer> auctionMortgageNumbers = client.getMortgagesByStage("Disbursed:");
			for (int eachGseMortgageNumber : auctionMortgageNumbers) {

				CustomerDetails customerDetails = client.getCustomerDetails(eachGseMortgageNumber);
				auctionCustomerList.add(customerDetails);

			}

			if (auctionCustomerList.size() != 0)
				request.setAttribute("auctionCustomerList", auctionCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/bankAuctionMortgages.jsp");

		}

		else if (action.equals("auction")) {

			String status = "";
			String[] selectCustomerMortgageNumbers = request.getParameterValues("customer");

			for (String eachAuctionMortgage : selectCustomerMortgageNumbers) {
				int eachGseMortgageNumber = Integer.parseInt(eachAuctionMortgage);
				String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"
						+ eachGseMortgageNumber + ",\\\"ModifiedBy\\\":\\\"" + role
						+ "\\\",\\\"MortgageStage\\\":\\\"Disbursed:Ready to Sell\\\"}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";
				String chainCodeResponse = client.invokeChainCode(payLoad);

				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

			}
			if (status.equals("OK"))
				request.setAttribute("successMsg", "Auction updated successfully.");
			else
				request.setAttribute("failureMsg", "Error! Please come back and try again later.");
			dispatcher = request.getRequestDispatcher("/bankAuctionMortgages.jsp");

		} else if (action.equals("reviewAuction")) {

			List<CustomerDetails> reviewAuctionCustomerList = new ArrayList<CustomerDetails>();
			List<Integer> auctionMortgageNumbers = client.getMortgagesByStage("Disbursed:Ready to Sell");
			for (int eachMortgageNumber : auctionMortgageNumbers) {

				CustomerDetails customerDetails = client.getCustomerDetails(eachMortgageNumber);
				reviewAuctionCustomerList.add(customerDetails);

			}

			if (reviewAuctionCustomerList.size() != 0)
				request.setAttribute("reviewAuctionCustomerList", reviewAuctionCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/bankReviewAuction.jsp");

		}

		else if (action.equals("reviewSell")) {

			String status = "";
			String[] selectCustomerMortgageNumbers = request.getParameterValues("customer");
			int discountPercentage = Integer.parseInt(request.getParameter("discountPercentage"));

			for (String eachGseMortgage : selectCustomerMortgageNumbers) {
				int eachGseMortgageNumber = Integer.parseInt(eachGseMortgage);
				CustomerDetails customerDetails = client.getCustomerDetails(Integer.parseInt(eachGseMortgage));
				int ownershipCost = (customerDetails.getRemainingMortgageAmount() * (100 - discountPercentage)) / 100;
				String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"
						+ eachGseMortgageNumber + ",\\\"ModifiedBy\\\":\\\"" + role + "\\\",\\\"Ownershipcost\\\":"
						+ ownershipCost + "}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";
				String chainCodeResponse = client.invokeChainCode(payLoad);

				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

			}
			if (status.equals("OK"))
				request.setAttribute("successMsg", "Auction updated successfully.");
			else
				request.setAttribute("failureMsg", "Error! Please come back and try again later.");

			dispatcher = request.getRequestDispatcher("/bankAuctionMortgages.jsp");

		} else if (action.equals("closeAuction")) {

			String status = "";
			String[] selectCustomerMortgageNumbers = request.getParameterValues("customer");

			for (String eachCloseAuctionMortgage : selectCustomerMortgageNumbers) {
				int eachGseMortgageNumber = Integer.parseInt(eachCloseAuctionMortgage);
				String payLoad = "{\"jsonrpc\": \"2.0\", \"method\": \"invoke\", \"params\": { \"type\": 1, \"chaincodeID\": { \"name\": \"\" }, \"ctorMsg\": { \"function\": \"modify_mortgage\", \"args\": [ \"{\\\"MortgageNumber\\\":"
						+ eachGseMortgageNumber + ",\\\"ModifiedBy\\\":\\\"" + role
						+ "\\\",\\\"MortgageStage\\\":\\\"Disbursed:\\\"}\" ] },  \"secureContext\": \"admin\" }, \"id\": 0 }";
				String chainCodeResponse = client.invokeChainCode(payLoad);

				JSONObject chainCodeReponseJson = new JSONObject(chainCodeResponse);
				status = chainCodeReponseJson.getJSONObject("result").get("status").toString();

			}
			if (status.equals("OK"))
				request.setAttribute("successMsg", "Auction closed successfully.");
			else
				request.setAttribute("failureMsg", "Error! Please come back and try again later.");
			dispatcher = request.getRequestDispatcher("/bankAuctionMortgages.jsp");

		}

		dispatcher.forward(request, response);

	}

}
