package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;
import com.dm.utils.DreamMortgageUtils;


public class PartnerBankServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public PartnerBankServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
					
		RequestDispatcher dispatcher = null;		
		String role = "Partner Bank";
		DreamMortgageUtils utils = new DreamMortgageUtils();
		RestServiceClientServlet client = new RestServiceClientServlet();
		String action = request.getParameter("action");

		if (action.equals("getPurchase")) {
			
			List<CustomerDetails> getCustomerList = utils.getAllMortgageeDetailsByStageAndConformedMortgage("Disbursed:Ready to Sell",false,false);
			
			if (getCustomerList.size() != 0)
				request.setAttribute("getCustomerList", getCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/partnerBankPurchase.jsp");

		}


		else if (action.equals("viewPurchased")) {

			List<CustomerDetails> purchasedCustomerList = utils.getAllMortgageeDetailsByStageAndConformedMortgage("Disbursed:Sold",false,false);

			if (purchasedCustomerList.size() != 0)
				request.setAttribute("purchasedCustomerList", purchasedCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/partnerBankViewPurchases.jsp");

		}
				
		else {
			
			request.setAttribute("errorMsg", "Error! Please try again later.");
			dispatcher = request.getRequestDispatcher("/partnerBankPurchase.jsp");
		
		}

		dispatcher.forward(request, response);	
		
	}
	

}
