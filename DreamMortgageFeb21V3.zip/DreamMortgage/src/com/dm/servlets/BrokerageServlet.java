package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;

public class BrokerageServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		
		String role = "Brokerage";
		RestServiceClientServlet client = new RestServiceClientServlet();
		String action = req.getParameter("action");
	
		if(action.equals("get")){
		List<CustomerDetails> customersDetails = client.getAllMortgageeDetails();
		
				if ((customersDetails.size()!=0)) 
					req.setAttribute("customersDetails", customersDetails);
				else
					req.setAttribute("errorMsg", "Sorry! No data available for your query");
				dispatcher = req.getRequestDispatcher("/brokerageEntity.jsp");

		}
		dispatcher.forward(req, resp);
	}
	
}