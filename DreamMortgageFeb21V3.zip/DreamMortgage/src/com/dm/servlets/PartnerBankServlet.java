package com.dm.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.json.JSONArray;
import org.json.JSONObject;

import com.dm.beans.CustomerDetails;


public class PartnerBankServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public PartnerBankServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
					
		RequestDispatcher dispatcher = null;		
		String role = "Partner Bank";

		RestServiceClientServlet client = new RestServiceClientServlet();
		String action = request.getParameter("action");

		if (action.equals("getPurchase")) {
			
			List<CustomerDetails> getCustomerList = new ArrayList<CustomerDetails>();

			List<Integer> getCustomerMortgageNumbers = client.getMortgagesByStage("Disbursed:Ready to Sell");
			for (int eachMortgageNumber : getCustomerMortgageNumbers) {
				
				CustomerDetails customerDetails = client.getCustomerDetails(eachMortgageNumber);
				getCustomerList.add(customerDetails);

			}

			if (getCustomerList.size() != 0)
				request.setAttribute("getCustomerList", getCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/partnerBankPurchase.jsp");

		}


		else if (action.equals("viewPurchased")) {

			List<CustomerDetails> purchasedCustomerList = new ArrayList<CustomerDetails>();

			List<Integer> getCustomerMortgageNumbers = client.getMortgagesByStage("Disbursed:Sold");
			for (int eachMortgageNumber : getCustomerMortgageNumbers) {
				
				CustomerDetails customerDetails = client.getCustomerDetails(eachMortgageNumber);
				if(customerDetails.getMortgagePropertyOwnership().equals("Lending Bank"))
					purchasedCustomerList.add(customerDetails);

			}

			if (purchasedCustomerList.size() != 0)
				request.setAttribute("purchasedCustomerList", purchasedCustomerList);
			else
				request.setAttribute("errorMsg", "Sorry! No data available for your query");
			dispatcher = request.getRequestDispatcher("/partnerBankViewPurchases.jsp");

		}
				
		else {
			
			request.setAttribute("errorMsg", "Error! Please try again later.");
			dispatcher = request.getRequestDispatcher("/partnerBankPurchase.jsp");
		
		}

		dispatcher.forward(request, response);	
		
	}
	

}
